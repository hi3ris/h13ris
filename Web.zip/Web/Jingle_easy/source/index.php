<?php


function getInspire(): string
{
    $quotes = [
        "Believe in yourself and all that you are. Know that there is something inside you that is greater than any obstacle.",
        "The only way to achieve the impossible is to believe it is possible.",
        "Success is not the key to happiness. Happiness is the key to success. If you love what you are doing, you will be successful.",
        "The harder you work for something, the greater you’ll feel when you achieve it.",
        "Don’t watch the clock; do what it does. Keep going.",
        "Your limitation—it’s only your imagination.",
        "Push yourself, because no one else is going to do it for you.",
        "Dream it. Wish it. Do it.",
        "Success doesn’t just find you. You have to go out and get it.",
        "Great things never come from comfort zones."
    ];

    $creds = json_decode(file_get_contents('php://input'), true);
    $password = "aaO8zKZF";

    if (isset($creds['__']) && sha1($creds['__']) == sha1($password)) {
        if ($creds['__'] !== $password) {
            return 'NCTF{y0u_l3arn_juggling_in_jungle_99d3cd}';
        }
    }

    return $quotes[rand(0, 9)];

}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jingle Jingle</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.2.1/flowbite.min.css" rel="stylesheet" />
</head>

<body class="bg-gray-900 mt-10">
    <section class="bg-gray-900">
        <div class="py-8 px-4 mx-auto max-w-screen-xl text-center">
            <h1 class="mb-4 text-4xl font-extrabold tracking-tight leading-none text-gray-900 md:text-5xl lg:text-6xl text-white">
                <?= getInspire() ?>
            </h1>
            <p class="mb-8 text-lg font-normal text-gray-500 lg:text-xl sm:px-16 xl:px-48 text-gray-400">
                Didn't like this one? Generate another
            </p>
            <div class="flex flex-col mb-8 lg:mb-16 space-y-4 sm:flex-row sm:justify-center sm:space-y-0 sm:space-x-4">
                <a href="https://youtu.be/0EYTBrSjpPY?t=2" target="_blank" class="inline-flex justify-center items-center py-3 px-5 text-base font-medium text-center text-white rounded-lg bg-primary-700 hover:bg-primary-800 focus:ring-4 border-gray-300 focus:ring-primary-300 focus:ring-primary-900">
                    Learn more
                    <svg class="ml-2 -mr-1 w-5 h-5" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                        <path fill-rule="evenodd" d="M10.293 3.293a1 1 0 011.414 0l6 6a1 1 0 010 1.414l-6 6a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-4.293-4.293a1 1 0 010-1.414z" clip-rule="evenodd"></path>
                    </svg>
                </a>
                <button onClick="window.location.reload();" class="inline-flex justify-center items-center py-3 px-5 text-base font-medium text-center text-gray-900 rounded-lg border border-gray-300 hover:bg-gray-100 focus:ring-4 focus:ring-gray-100 text-white border-gray-700 hover:bg-gray-700 focus:ring-gray-800">
                    Another One
                </buton>
            </div>
        </div>
    </section>
    <section class="bg-gray-900">
        <div class="gap-16 items-center py-8 px-4 mx-auto max-w-screen-xl lg:grid lg:grid-cols-2">
            <div class="grid grid-cols-2 gap-4">
                <img class="w-full rounded-lg" src="https://ngroup.gumlet.io/IMAGE/IMAGE-S1-00019/108017-joker-avdv.jpg?w=376&dpr=2.6">
                <img class="mt-4 w-full lg:mt-10 rounded-lg" src="https://ngroup.gumlet.io/IMAGE/IMAGE-S1-00019/108017-joker-avdv.jpg?w=376&dpr=2.6">
            </div>
            <div class="grid grid-cols-2 gap-4">
                <img class="w-full rounded-lg" src="https://ngroup.gumlet.io/IMAGE/IMAGE-S1-00019/108017-joker-avdv.jpg?w=376&dpr=2.6">
                <img class="mt-4 w-full lg:mt-10 rounded-lg" src="https://ngroup.gumlet.io/IMAGE/IMAGE-S1-00019/108017-joker-avdv.jpg?w=376&dpr=2.6">
            </div>
        </div>
    </section>
</body>

</html>