<?php


function getInspire(): string
{
    $quotes = [
        "Believe in yourself and all that you are. Know that there is something inside you that is greater than any obstacle.",
        "The only way to achieve the impossible is to believe it is possible.",
        "Success is not the key to happiness. Happiness is the key to success. If you love what you are doing, you will be successful.",
        "The harder you work for something, the greater you’ll feel when you achieve it.",
        "Don’t watch the clock; do what it does. Keep going.",
        "Your limitation—it’s only your imagination.",
        "Push yourself, because no one else is going to do it for you.",
        "Dream it. Wish it. Do it.",
        "Success doesn’t just find you. You have to go out and get it.",
        "Great things never come from comfort zones."
    ];

    $creds = json_decode(file_get_contents('php://input'), true);
    $password = "aaO8zKZF";

    if (isset($creds['__']) && sha1($creds['__']) == sha1($password)) {
        if ($creds['__'] !== $password) {
            return 'NCTF{...REDACTED...}';
        }
    }

    return $quotes[rand(0, 9)];

}

?>