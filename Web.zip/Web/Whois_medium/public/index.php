<?php

error_reporting(0);

$output = null;
$host_regex = "/^[0-9a-zA-Z][0-9a-zA-Z\.-]+$/";
$query_regex = "/^[0-9a-zA-Z\. ]+$/";

if (
  isset($_GET['query']) && isset($_GET['host']) &&
  is_string($_GET['query']) && is_string($_GET['host'])
) {

  $query = $_GET['query'];
  $host  = $_GET['host'];

  if (!preg_match($host_regex, $host) || !preg_match($query_regex, $query)) {
    $output = "Invalid host or query";
  } else {
    $output = shell_exec("/usr/bin/whois ${host} ${query}");
  }
} else {
  $output = "please provide host and query";
}

?>