<?php
echo "On a désert, loin de tout, <br>
Vivait un prince aux rêves si fous. 👑 <br>
Il voguait sur des mondes dorés, <br>
Cherchant des amis et des secrets. 🌟 <br>
<br>
Son royaume, un astéroïde minuscule, <br>
Où il jardinait avec amour, une passion fertile. 🌹 <br>
Mais un jour, il rencontra, <br>
Une rose aux pétales, toute en émoi. 🌹 <br>
<br>
Il quitta son monde, un voyage éternel, <br>
Pour explorer des étoiles, un chemin pluriel. ✨ <br>
Des planètes pleines de curiosités, <br>
Chaque rencontre, une nouvelle vérité. 🚀 <br>
<br>
Il rencontra un renard, sage et vif, <br>
Apprenant des leçons sur l'amour, si précieux et actif. 🦊 <br>
Avec chaque ami, une leçon sur la vie, <br>
Le prince découvrit que l’essentiel est invisible, à l’œil nu, en fait, la magie. 💫 <br>
<br>
Ainsi, à travers les cieux étoilés, <br>
Il apprit que les liens créés <br>
Sont ce qui rend la vie si belle, <br>
Des moments partagés, tels des étincelles. 🌠 <br>
<br>
Le Petit Prince, dans sa quête sincère, <br>
Découvrit l'amour, si rare et si clair. <br>
Il retourna chez lui, avec un cœur apaisé, <br>
Sachant que les vraies richesses sont celles à aimer.";
?>
