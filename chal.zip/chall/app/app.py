from flask import Flask, render_template, request
import subprocess

app = Flask(__name__)

FLAG_FILE = "flag.txt"

BANNED_COMMANDS = ['read', 'import', 'print', 'open', 'exec', 'eval', '__', 'os', 'sys', 'subprocess','flag','builtins','system','module','globals','input','python3','python','encode','readline','class','ys','sy','cat','ls']

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/run", methods=["POST"])
def run():
    user_command = request.form.get("command", "")

    if any(banned in user_command for banned in BANNED_COMMANDS):
        return "Commande interdite!"

    try:
        result = subprocess.run(
            ["python3", "-c", user_command],
            text=True,
            capture_output=True,
            timeout=2,
        )
        output = result.stdout + result.stderr
    except Exception as e:
        output = str(e)

    return output

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
