<?php
    // NCTF{smoke_gbekui_wrapper_when_allow_include_url_equal_On_f38661ef}
?>