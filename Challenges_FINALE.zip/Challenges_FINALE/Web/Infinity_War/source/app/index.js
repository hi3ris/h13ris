const fastify = require('fastify');
const path = require('path');
const { flag } = require('./secret');

// generate posts
let posts = [];
for (let i = 0; i < 10000; i++) {
  posts.push({
    title: `Dummy post - ${i}`,
    content: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'.trim()
  });
}

posts[2024] = {
  title: 'Flag',
  content: `Wow, how do you fight to read this post? Anyway, the flag is: <code>${flag}</code>`
};

const app = fastify({ logger: true });
app.register(require('point-of-view'), {
  engine: {
    ejs: require('ejs')
  },
  root: path.join(__dirname, 'view')
});
app.register(require('fastify-static'), {
  root: path.join(__dirname, 'static'),
  prefix: '/static/',
});

app.get('/', async (request, reply) => {
  return reply.view('index.ejs', { posts });
});

app.get('/posts/:id', async (request, reply) => {
  // id should not be negative 
  if (/^[\b\t\n\v\f\r \xa0]*-/.test(request.params.id)) {
    return reply.view('posts.ejs', {
      title: 'Access denied',
      content: 'Hacking attempt detected.'
    });
  }

  let id = parseInt(request.params.id, 10);

  // free users cannot read posts with id > 9
  if (id > 9) {
    return reply.view('posts.ejs', {
      title: 'Access denied',
      content: 'You need to become a premium user to read this content.'
    });
  }

  const post = posts.at(id) ?? {
    title: 'Not found',
    content: 'The requested post was not found.'
  };

  return reply.view('posts.ejs', post);
});

const start = async () => {
  try {
    await app.listen(3000, '0.0.0.0');
    app.log.info(`server listening on ${app.server.address().port}`);
  } catch (err) {
    app.log.error(err);
    process.exit(1);
  }
};
start();