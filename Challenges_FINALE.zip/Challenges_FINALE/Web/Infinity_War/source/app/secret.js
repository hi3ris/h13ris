module.exports = {
    flag: 'NCTF{Array.prototype.at_Blank_to_g3t_n3gative_Bypass_like_n00bz}'
};