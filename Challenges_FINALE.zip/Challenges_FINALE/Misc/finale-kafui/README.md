# Amok

| Phase         | Catégorie  |  Difficulté  | Nombre de résolutions |
|:-------------:|:----------:|:------------:|:---------------------:|
| Finale France | crypto     |   Facile     |               24 / 50 | 


### Description

Une de nos sources a réussi à intercepter ce message et nous informe que le contenu est probablement du français. Arrivez-vous à le déchiffrer ?

Note : le flag est à fournir en minuscules.

SHA256(`ciphertext.txt`): `89695bacc9fdbff8c153a0fe74eecbb16d131f6027423b91a7258a4ffd552664`.
