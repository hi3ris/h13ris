# QRCode

| Phase          | Catégorie  |   Difficulté   | Nombre de résolutions |
|:--------------:|:----------:|:--------------:|:---------------------:|
| Pré-sélections | misc       |    Facile      |            186 / 1241 | 

### Description

QR Codes everywhere!
