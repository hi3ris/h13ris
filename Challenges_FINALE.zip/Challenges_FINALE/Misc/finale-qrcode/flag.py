flag = "NCTF{qrcode_every_where_c49bce13d47ea864324326d4cefa}"
