# Petit Poucet

| Phase               | Catégorie  |  Difficulté  | Nombre de résolutions |
|:-------------------:|:----------:|:------------:|:---------------------:|
| Entrainement TeamFR | misc       |    Moyen     |                 0 / 5 |


### Description

Traquez le petit poucet !
