flag = "NCTF{petitpocetveryhardtofind77ae8c0d9dc2fa95a8f3f2a4}"
