# 2tp

| Phase          | Catégorie    |   Difficulté  | Nombre de résolutions |
|:--------------:|:------------:|:-------------:|:---------------------:|
| Pré-sélections | crypto       |      Facile   |            124 / 1241 |

### Description

Venez tester notre chiffreur universel ! Nous utilisons des technologies de pointe, garanties inviolables !
Pour preuve, nous vous donnons le flag chiffré et jamais vous ne pourrez le retrouver.
