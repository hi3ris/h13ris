# Crypto

| Phase               | Catégorie |   Difficulté  | Nombre de résolutions |
|:-------------------:|:---------:|:-------------:|:---------------------:|
| Entrainement TeamFR | crypto    |     Facile    |                  5 /5 |

### Description

Le flag est simplement affiché dans l'image ci-dessous.

![Cipher](chall.png)
