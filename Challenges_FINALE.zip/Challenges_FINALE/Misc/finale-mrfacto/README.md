# Factorial

| Phase          | Catégorie  |  Difficulté  | Nombre de résolutions |
|:--------------:|:----------:|:------------:|:---------------------:|
| Pré-sélections | misc       |   Difficile  |             49 / 1241 |

## Description

Tout est là : [https://fr.wikipedia.org/wiki/Factorielle](https://fr.wikipedia.org/wiki/Factorielle)
