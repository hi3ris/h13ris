# Protation

| Phase          | Catégorie  |  Difficulté   | Nombre de résolutions |
|:--------------:|:----------:|:-------------:|:---------------------:|
| Finale France  | misc       |    Difficile  |                0 / 50 |

### Description

Saurez-vous trouver la chaine qui permet d'afficher le flag ?

Note : **Aucun *bruteforce* n'est nécessaire.**
