# m04r sigz

| Phase          | Catégorie    |   Difficulté  | Nombre de résolutions |
|:--------------:|:------------:|:-------------:|:---------------------:|
| Pré-sélections | crypto       |       Moyen   |             51 / 1241 |

### Description

Testez la robustesse de notre *SecureSigner* !
