from Crypto.Util.number import getPrime

# Secured Crypto System :)

p = getPrime(1024)
q = getPrime(1024)
n = p * q
e = 0x10001

flag = b'[REDACTED]'
encrypted = []

for i in flag:
    encrypted.append(pow(i, e, n))

with open("encrypted.txt", "w") as f:
    f.write(str(encrypted))

with open("param.txt", "w") as f:
    f.write(f'n = {n}\n')
    f.write(f'e = {e}')