#include <stdio.h>
#include <string.h>

int a[25] = {84, 128, 70, 102, 28, 50, 75, 48, 138, 37, 79, 102, 74, 66, 93, 51, 138, 69, 56};
int b[25] = {-12636, -13065, -12936, -12040, -18573, -15251, -21244, -19305, -8235, -16950, -22932, -8008, -17400, -20520, -18430, -19372, -9163, -16632, -22625};

int calc(char x, int a, int b){
	int tmp = (x * x) + (a * x) + b;
	if(tmp == 0){
		return 1;
	}else{
		return 0;
	}
	
}
int main(int argc, char *argv[]){
	int result = 0;
	int i;

	int KEY_LENGTH = 19;
	
	if(argc == 1){
		printf("Usage: crackyou <flag>\n");
	}else{

		if(strlen(argv[1]) == KEY_LENGTH){
			for(i=0; i < KEY_LENGTH - 1; i++){
				result = calc(argv[1][i] , a[i], b[i]);
				if(result == 0) break;
			}
			if(result == 1){
				printf("Conguratulations!! Flag is %s\n", argv[1]);
				return 1;
			}
		}else{
				printf("Oops, Try again.\n");	
		}
	}
	
	return 0;
}