from fastapi import FastAPI, HTTPException, Depends, Request

messages = {
    "GET": "Bienvenue ! Désormais, tu fais partie des nôtres.",
    "POST": "404 not found",
    "PATCH": "404 not found",
    "DELETE": "404 not found",
    "OPTIONS": "404 not found",
    "HEAD": "404 not found",
    "PUT": [
            "NCTF{4lw4y5_ch3ck_h77p_m37h0d5_15n'7_17?}",
            "Tips: HTTP définit un ensemble de méthodes de requête qui indiquent l'action que l'on souhaite réaliser sur la ressource indiquée. Bien qu'on rencontre également des noms (en anglais), ces méthodes sont souvent appelées verbes HTTP. Chacun d'eux implémente une sémantique différente mais certaines fonctionnalités courantes peuvent être partagées par différentes méthodes (e.g. une méthode de requête peut être sûre (safe), idempotente ou être mise en cache (cacheable))."
    ],
}

error = {
    "header": "membre",
    "message": "Access refusé - Vous ne faites pas partie de nos équipes. Cet incident est remonté à notre équipe SOC."
}


app = FastAPI()


async def check_header(request: Request):
    if request.headers.get('membre') != "true":
        raise HTTPException(
            status_code=400, detail=error
        )
    return True


@app.put("/")
async def flag_put(header_check: bool = Depends(check_header)):
    return {"flag": messages["PUT"]}


@app.get("/")
async def flag_get(header_check: bool = Depends(check_header)):
    return {"message": messages["GET"]}


@app.post("/")
async def flag_post(header_check: bool = Depends(check_header)):
    return {"message": messages["POST"]}


@app.delete("/")
async def flag_delete(header_check: bool = Depends(check_header)):
    return {"message": messages["DELETE"]}


@app.head("/")
async def flag_delete(header_check: bool = Depends(check_header)):
    return {"message": messages["HEAD"]}


@app.options("/")
async def flag_delete(header_check: bool = Depends(check_header)):
    return {"message": messages["OPTIONS"]}


@app.patch("/")
async def flag_delete(header_check: bool = Depends(check_header)):
    return {"message": messages["PATCH"]}
