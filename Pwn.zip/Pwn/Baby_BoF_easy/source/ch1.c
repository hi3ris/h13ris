//gcc -o ch1 ch1.c -no-pie -fno-stack-protector
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>

void print_flag()
{
    const unsigned MAX_LENGTH = 100;
	char buffer[MAX_LENGTH];

	FILE * inputFile = fopen( "flag.txt", "r" );
	if ( inputFile == NULL ) {
        printf( "Cannot open file %s\n", "flag.txt" );
        exit( -1 );
    }
    fgets( buffer, MAX_LENGTH, inputFile );
    printf("Here is your flag: %s",buffer);
}

int main(int argc, char **argv)
{
    volatile int modified;
    char buffer[64];

    modified = 0;
    puts("Give me something: ");
    gets( buffer );

    
    if(modified == 0xdeadbeef) {
        puts("you have correctly got the variable to the right value\n");
        print_flag();
    } else {
        printf("tchaley try harder, you got 0x%08x\n", modified);
    }
}