//  gcc -o source/ch2 source/ch2.c -no-pie -Wimplicit-function-declaration -fno-stack-protector
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>

void win()
{
    const unsigned MAX_LENGTH = 100;
	char buffer[MAX_LENGTH];

	FILE * inputFile = fopen( "flag.txt", "r" );
	if ( inputFile == NULL ) {
        printf( "Cannot open file %s\n", "flag.txt" );
        exit( -1 );
    }
    
    fgets( buffer, MAX_LENGTH, inputFile );
    printf("Here is your flag: %s",buffer);

}


int main(int argc, char **argv)
{
    char buffer[0x80];

    puts("Oléyia ? where do you want to go: ");
    gets( buffer );
}