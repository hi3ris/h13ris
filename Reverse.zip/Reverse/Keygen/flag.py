
FLAG = "NCTF{Gg_you_Are_A_mat3r_7895563}"

