#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
    
    char flag[100];
    if (argc < 2){
        printf("Usage: ./ch1 password \n");
        return 0;
    }

    if (strcmp(argv[1], "cesame") == 0) {
        strcpy(flag, "NCTF{r3verse_eNg_1s_v3ry_e4sy_ri9ht????}");
        printf("Access granted! here is your flag: %s\n", flag);
    } else {
        printf("Access denied!\n");
    }

    return 0;
}