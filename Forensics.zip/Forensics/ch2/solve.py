from scapy.all import *
import base64

def extract_icmp_message(pcap_file):
    packets = rdpcap(pcap_file)
    message_fragments = []

    for pkt in packets:
        if ICMP in pkt and Raw in pkt:
            if pkt[IP].dst == "192.168.20.2":
                message_fragments.append(pkt[Raw].load.decode('utf-8', errors='ignore'))

    message = ''.join(message_fragments)
    return message

pcap_file = 'source/intercept.pcap'
message = extract_icmp_message(pcap_file)
print(f"Message : {base64.b64decode(message)}")
