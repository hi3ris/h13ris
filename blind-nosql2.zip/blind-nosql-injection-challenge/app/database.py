from pymongo import MongoClient
from config import MONGO_URI, DATABASE_NAME, COLLECTION_NAME_ARTICLES

client = MongoClient(MONGO_URI)
db = client[DATABASE_NAME]

def search_users(query):
  
    return db.users.find({"$where": f"this.username == '{query}'"})

def get_user(credentials):
    return db.users.find_one({"username": credentials["username"], "password": credentials["password"]})