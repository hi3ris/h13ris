from flask import Flask, request, render_template, redirect, session
from database import search_users, get_user

app = Flask(__name__)
app.secret_key = "super_secret_key"  # Nécessaire pour les sessions

@app.route('/')
def index():
    # Rediriger vers la page de connexion si non authentifié
    if not session.get('logged_in'):
        return redirect('/login')
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        try:
            user = get_user({"username": username, "password": password})
        except Exception as e:
            return f"Erreur lors de la récupération de l'utilisateur : {e}", 500
        if user:
            session['logged_in'] = True
            session['username'] = user['username']
            return redirect('/')
        else:
            return "Identifiants incorrects, réessayez."
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect('/login')

@app.route('/search', methods=['GET'])
def search():
    # Vérification de l'authentification
    if not session.get('logged_in'):
        return redirect('/login')

    query = request.args.get('query', '')

    try:
        users = search_users(query)
        return render_template('search.html', users=users, query=query)

    except Exception as e:
            return f"Erreur lors de la récupération de l'article : {e}", 500
    
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)

