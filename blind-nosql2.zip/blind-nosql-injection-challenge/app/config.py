MONGO_URI = "mongodb://mongodb:27017/blindnosql"
DATABASE_NAME = "blindnosql"
COLLECTION_NAME_ARTICLES = "articles"
COLLECTION_NAME_USERS = "users"

