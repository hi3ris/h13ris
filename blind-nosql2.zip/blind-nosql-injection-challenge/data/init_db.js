db = db.getSiblingDB('blindnosql');

db.users.drop();
db.users.insertMany([
    { 
        username: "admin", 
        password: "NCTF{GG_7H3_R0CK5T4R_D1D_17_4G41N}", 
        name: "Admin User", 
        email: "admin@nctf.local" 
    },
    { 
        username: "user1", 
        password: "mypassword", 
        name: "User One", 
        email: "user1@nctf.local" 
    }
]);

print("Database initialized with name and email fields!");


