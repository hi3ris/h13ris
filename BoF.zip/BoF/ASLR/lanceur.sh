#!/bin/bash

# Port sur lequel vous souhaitez écouter
port=8082

# Chemin vers votre programme binaire
chemin_vers_votre_binaire="./aslr"  # Assurez-vous que le chemin est correct

# Limiter le nombre de processus simultanés
nombre_max_processus=10

# Fonction pour gérer les connexions
serve_binary() {
  local pid_array=()  # Tableau pour stocker les PID des processus

  while true; do
    # Attendre une connexion sur le port spécifié
    { exec nc -l -p $port -e "$chemin_vers_votre_binaire"; } &

    # Ajouter le PID du processus en arrière-plan au tableau
    pid_array+=($!)

    # Si le nombre de processus atteint la limite, attendre que l'un d'entre eux se termine
    if [ ${#pid_array[@]} -ge $nombre_max_processus ]; then
      wait -n  # 
      unset 'pid_array[0]'  # Supprimer le PID du processus terminé du tableau
    fi
  done
}

# Gestion de la fermeture propre du script
trap 'echo "Arrêt du script..."; exit 0' INT TERM

# Lancer la fonction de gestion des connexions
serve_binary

