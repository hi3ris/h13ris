#!/usr/bin/python3

from flag import FLAG

def check_key(key):

    if len(key) != 20 or ord(key[0]) % 3 != 1 or ord(key[1]) % 5 != 4 or not key[2].isdigit() or not key[3].isupper() or ord(key[4]) <= ord(key[3]) - 2 or not key[5].islower() or int(key[6]) % 2 != 0 or ord(key[7]) >= ord(key[6]) + 3 or not key[8].isupper() or ord(key[9]) % 2 != 1 or key[10].isdigit() or ord(key[11]) % 4 != 0 or not key[12].islower() or ord(key[13]) >= ord(key[12]) + 2 or not key[14].isupper() or ord(key[15]) <= ord(key[14]) + 5 or not key[16].isdigit() or int(key[17]) >= int(key[16]) + 1 or not key[18].islower() or ord(key[19]) >= ord(key[18]) - 4:
        return False
    return True

def main():



    print("""
 NCTF Key Validation System
      _____
     /   _ \\__.--._._--.-_
    |   |_| ______________\\
     \\_____/
""")

    key = input("Enter your activation key: ")
    if check_key(key):
        print(f"Congratulations! You unlocked the door, here's your prize: {FLAG}")
        exit()
        return 0
    else:
        print("Sadly your key didn't work this time, keep working on it!")
        return 1

if __name__ == "__main__":
    while True:
        main()
