#! /usr/bin/python3

# flag="NCTF{...*.....}"

from binascii import hexlify

def wrap(value):
    return chr(value)

final=""
for xy in range(0,len(flag)):
    i=ord(flag[xy])
    if (xy % 2 == 0):
        final+=wrap(i ^ 0xd)
        continue
    elif (xy % 3 == 0 ):
        final+=wrap((i << 0x2) + 0x2 )
        continue
    elif (xy % 5 == 0 ):
        final+=wrap(i + 0x4c)
        continue
    elif (xy % 7 == 0 ):
        final+=wrap(i - (0xd^2))
        continue
    else:
        final+=wrap(i)
        continue

print(final)
print(hexlify(final.encode()).decode())

# result = '434359c49a76c2b2612534c3965234616c52c39e6533527739c7a6526138c2823fc3926c61346339c39234c2ad6b663dc3863464343170'