#!/bin/bash
for i in {1..10}; do
    echo "Va lém.... va lém..... It means..... Attrape moi si tu peux :)"
done
exit 0
