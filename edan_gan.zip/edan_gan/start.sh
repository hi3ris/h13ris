while :
do
	httpd -D FOREGROUND
done
