<?php 
if(!isset($_SESSION)) 
{ 
    session_start(); 
}

if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Challenge Edan Gan</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" 
          integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" 
          crossorigin="anonymous">
    <style>
        body {
            background: linear-gradient(90deg, #1c1c3c, #4a90e2);
            color: #fff;
            font-family: 'Arial', sans-serif;
            animation: gradientAnimation 10s infinite alternate;
        }

        @keyframes gradientAnimation {
            0% { background: #1c1c3c; }
            50% { background: #4a90e2; }
            100% { background: #1c1c3c; }
        }

        h1, p {
            text-align: center;
            margin-top: 20px;
        }

        .list-group-item a {
            color: #1c1c3c;
            font-weight: bold;
            text-decoration: none;
        }

        .list-group-item a:hover {
            color: #4a90e2;
        }

        .btn {
            margin: 5px;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <?php
            if (isset($_POST['name'])) {
                $_SESSION['name'] = $_POST['name'];
            }

            if (isset($_SESSION['name'])) {
                if (isset($_GET['file'])) {
                    echo "<a class=\"btn btn-primary\" href=\"index.php\" role=\"button\">Retour</a>";
                    echo "<a class=\"btn btn-danger\" href=\"?logout=1\" role=\"button\">Déconnexion</a><br>";
                    include 'files/' . $_GET['file'];
                } else {
                    echo "<h1>Bonjour, " . $_SESSION['name'] . " !</h1>";
                    echo "<a class=\"btn btn-danger\" href=\"?logout=1\" role=\"button\">Déconnexion</a>";
                    echo "<ul class=\"list-group mt-4\">";
                    foreach (scandir("files") as $val) {
                        if(strcmp($val, ".") && strcmp($val, "..")) {
                            echo "<li class=\"list-group-item my-1\"><a href='?file=$val'>$val</a></li>";
                        }
                    }
                    echo "</ul>";
                }
            } else {
                echo "<h1>Quel est votre nom ?</h1>";
                echo "<form action=\"/index.php\" method=\"post\" class=\"text-center mt-4\">";
                echo "<input type=\"text\" name=\"name\" class=\"form-control w-50 mx-auto\" placeholder=\"Entrez votre nom\" required>";
                echo "<button type=\"submit\" class=\"btn btn-success mt-3\">Soumettre</button>";
                echo "</form>";
            }
        ?>
    </div>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" 
            integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" 
            crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" 
            integrity="sha384-oBqDVmMz4fnFO9gybR3zj7mtUJ+1pbjTs1txz7wetQXfNWzK8MODpUeRa1N7AYc+" 
            crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" 
            integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIyht4f3eA12BB6qxNHIuVx3WWlpF+Vb06t9UM0v" 
            crossorigin="anonymous"></script>
</body>
</html>
