$inputFile = "flag.txt"
$outputFile = "Output.txt"
$Value = 3
$content = Get-Content -Path $inputFile -Raw
$result = ""

foreach ($char in $content.ToCharArray()) {
    $asciiValue = [int][char]$char
    $xResult = $asciiValue -bxor $Value
    $newChar = [char]$xResult
    $result += $newChar
}

Set-Content -Path $outputFile -Value $result
Write-Host "Le fichier a été traité et sauvegardé dans $outputFile"
